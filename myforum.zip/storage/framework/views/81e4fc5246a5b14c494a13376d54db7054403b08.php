<?php $__env->startSection('axtra-js'); ?>
	 <?php echo NoCaptcha::renderJs(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="container">
		
		<h1>Creer un topic</h1>

		<hr>

		<form action="<?php echo e(route('topics.store')); ?>" method="POST">
			<?php echo csrf_field(); ?>

			<div class="form-group">
				<label for='title'>Titre du topic</label>
				<input type="text" class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id='title' name="title">

				<?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
					<div class="invalid-feedback">
						<?php echo e($errors->first('title')); ?>

					</div>
				<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
			</div>

			<div class="form-group">
				<label for='content'>Votre topic</label>
				<textarea class="form-control <?php if ($errors->has('content')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('content'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id='content' name="content" rows="8"></textarea>

				<?php if ($errors->has('content')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('content'); ?>
					<div class="invalid-feedback">
						<?php echo e($errors->first('content')); ?>

					</div>
				<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

			</div>

			<div class="form-group">
				<?php echo NoCaptcha::display(); ?>

			</div>
			
			<button type="submit" class="btn btn-primary"> Créer un topic</button>
		</form>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravelApp\myforum\resources\views/topics/create.blade.php ENDPATH**/ ?>