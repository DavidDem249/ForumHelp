<?php $__env->startSection('extra-css'); ?>
	
	<style type="text/css">
		.bordure{
			border: 1px solid green;
		}
	</style>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('axtra-js'); ?>
	
	<script>
		function toggleReplyComment(id){
			let element = document.getElementById('replyComment-' + id);
			element.classList.toggle('d-none');
		}
	</script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="container">
		
		<div class="card">
			<div class="card-body">
				<h3 class="card-title" style="font-weight: bold;"><?php echo e($topic->title); ?></h3>
				<p><?php echo e($topic->content); ?></p>

				<div class="d-flex justify-content-between align-items-center">
					<small>
						Poster le <?php echo e($topic->created_at->format('d/m/Y à H:m')); ?>

					</small>

					<span class="badge badge-primary">
						<?php echo e($topic->user->name); ?>

					</span>
				</div>

				<div class="d-flex justify-content-between align-items-center mt-3">
					<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $topic)): ?>
						<a href="<?php echo e(route('topics.edit', $topic)); ?>" class="btn btn-warning"> Editer ce topic </a>
					<?php endif; ?>

					<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $topic)): ?>
						<form action="<?php echo e(route('topics.destroy', $topic)); ?>" method="POST">
							
							<?php echo csrf_field(); ?>
							<?php echo method_field('DELETE'); ?>

							<button type="submit" class="btn btn-danger">Supprimer</button>

						</form>
					<?php endif; ?>
				</div>

			</div>
		</div>

		<hr>
		<h4>Commentaires</h4>

		<?php $__empty_1 = true; $__currentLoopData = $topic->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<div class="card mb-2">
				<div class="card-body d-flex justify-content-between <?php echo e($topic->solution == $comment->id ? 'bordure' : ''); ?> ">
					<div>
						<?php echo e($comment->content); ?>


						<div class="d-flex justify-content-between align-items-center">
							<small>
								Poster le <?php echo e($comment->created_at->format('d/m/Y à H:m')); ?>

							</small>
							&nbsp;&nbsp; 
							<span class="badge badge-primary">
								<?php echo e($comment->user->name); ?>

							</span>
						</div>
					</div>

					<div>
						<?php if(!$topic->solution && auth()->user()->id == $topic->user_id): ?>

							<solution-button topic-id ="<?php echo e($topic->id); ?>" comment-id="<?php echo e($comment->id); ?>"></solution-button>
						<?php else: ?>
							<?php if($topic->solution == $comment->id): ?>
								<h4>
									<span class="badge badge-success">Déja marqué comme solution</span>
								</h4>
							<?php endif; ?>
						<?php endif; ?>
					</div>

				</div>
			</div>

			<?php $__currentLoopData = $comment->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $replyComment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="card mb-2 ml-5">
					<div class="card-body">
						<?php echo e($replyComment->content); ?>


						<div class="d-flex justify-content-between align-items-center">
							<small>
								Poster le <?php echo e($replyComment->created_at->format('d/m/Y à H:m')); ?>

							</small>

							<span class="badge badge-primary">
								<?php echo e($replyComment->user->name); ?>

							</span>
						</div>

					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php if(auth()->guard()->check()): ?>
				<button class="btn btn-info mb-3" onclick="toggleReplyComment(<?php echo e($comment->id); ?>)">
					Répondre
				</button>
				<form action="<?php echo e(route('comments.storeReply', $comment)); ?>" method="POST" class="mb-3 ml-5 d-none" id='replyComment-<?php echo e($comment->id); ?>'>
					<?php echo csrf_field(); ?>
					<div class="form-group">
						<label for='replyComment'>Ma réponse</label>
						<textarea class="form-control <?php if ($errors->has('replyComment')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('replyComment'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="replyComment" id='replyComment' rows="3"></textarea>

						<?php if ($errors->has('replyComment')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('replyComment'); ?>
							<div class="invalid-feedback">
								<?php echo e($errors->first('replyComment')); ?>

							</div>
						<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
					</div>
					<button class="btn btn-primary" type="submit">Répondre à ce commentaire</button>
				</form>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<div class="alert alert-info">Aucun commentaire pour ce topic</div>

		<?php endif; ?>

		<form method="POST" action="<?php echo e(route('comments.store',$topic)); ?>" class="mt-3">

			<?php echo csrf_field(); ?>

			<div class="form-group">
				<label for='content'>Votre commentaire</label>
				<textarea class="form-control <?php if ($errors->has('content')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('content'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id='content' rows="5" name="content">
					
				</textarea>

				<?php if ($errors->has('content')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('content'); ?>

					<div class="invalid-feedback">
						<?php echo e($errors->first('content')); ?>

					</div>

				<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

				<button type="submit" class="btn btn-primary mt-2">Soumettre mon commentaire</button>
			</div>
		</form>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravelApp\myforum\resources\views/topics/show.blade.php ENDPATH**/ ?>