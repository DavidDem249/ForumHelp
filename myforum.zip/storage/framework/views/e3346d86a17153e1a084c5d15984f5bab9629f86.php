<?php $__env->startSection('content'); ?>

	<div class="container">
		<div class="list-group">
			
			<?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="list-group-item">
					<h4>
						<a href="<?php echo e(route('topics.show', $topic)); ?>"> <?php echo e($topic->title); ?> 
						</a>
					</h4>

					<p><?php echo e($topic->content); ?></p>
					<div class="d-flex justify-content-between align-items-center">
						<small>
							Poster le <?php echo e($topic->created_at->format('d/m/Y à H:m')); ?>

						</small>

						<span class="badge badge-primary">
							<?php echo e($topic->user->name); ?>

						</span>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</div>
		<div class="d-flex justify-content-center mt-3">
			<?php echo e($topics->links()); ?>

		</div>
	</div>
		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravelApp\myforum\resources\views/topics/index.blade.php ENDPATH**/ ?>