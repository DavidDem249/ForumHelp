<?php $__env->startSection('content'); ?>
	
	<div class="container">
		
		<h1><?php echo e($topic->title); ?></h1>

		<hr>

		<form action="<?php echo e(route('topics.update', $topic)); ?>" method="POST">
			<?php echo csrf_field(); ?>

			<?php echo method_field('PUT'); ?> 

			<div class="form-group">
				<label for='title'>Titre du topic</label>
				<input type="text" class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id='title' value="<?php echo e($topic->title); ?>" name="title">

				<?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
					<div class="invalid-feedback">
						<?php echo e($errors->first('title')); ?>

					</div>
				<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
			</div>

			<div class="form-group">
				<label for='content'>Votre topic</label>
				<textarea class="form-control <?php if ($errors->has('content')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('content'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id='content' name="content" rows="8"> <?php echo e($topic->content); ?> </textarea>

				<?php if ($errors->has('content')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('content'); ?>
					<div class="invalid-feedback">
						<?php echo e($errors->first('content')); ?>

					</div>
				<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>

			</div>
			
			<button type="submit" class="btn btn-primary"> Modifier </button>
		</form>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravelApp\myforum\resources\views/topics/edit.blade.php ENDPATH**/ ?>